exports.id = 80;
exports.ids = [80];
exports.modules = {

/***/ 9747:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__ExSQi"
};


/***/ }),

/***/ 8218:
/***/ ((module) => {

// Exports
module.exports = {
	"nav_link": "Navbar_nav_link__eZQwP",
	"navbar": "Navbar_navbar__uNtpm"
};


/***/ }),

/***/ 4951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MyApp)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/mediaQuery.css
var mediaQuery = __webpack_require__(5650);
// EXTERNAL MODULE: ./Components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(8218);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Navbar/Navbar.jsx




const Navbar = ()=>{
    const [isScrolled, setIsScrolled] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>setIsScrolled(window.scrollY > 1);
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    const navbarClasses = `${(Navbar_module_default()).navbar} navbar navbar-expand-lg py-1 px-0 ${isScrolled ? "bg-light shadow fixed-top" : "bg-transparent fixed-top"}`;
    const liClasses = `${(Navbar_module_default()).nav_link} ${isScrolled ? "text-dark" : "text-light py-3"}`;
    return /*#__PURE__*/ jsx_runtime.jsx("header", {
        children: /*#__PURE__*/ jsx_runtime.jsx("nav", {
            className: navbarClasses,
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "container px-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                        href: "/",
                        className: `${liClasses} d-flex flex-column navbar-brand fw-bold fs-5 m-0 mb-1 p-0 opacity-100`,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("img", {
                                src: "/final-logo.png",
                                alt: "",
                                width: 100,
                                className: "m-auto"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                className: "text-sm m-0",
                                children: "للإستشارات الهندسية"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("button", {
                        className: "navbar-toggler",
                        type: "button",
                        "data-bs-toggle": "collapse",
                        "data-bs-target": "#navbarSupportedContent",
                        "aria-controls": "navbarSupportedContent",
                        "aria-expanded": "false",
                        "aria-label": "Toggle navigation",
                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                            className: "navbar-toggler-icon"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "collapse navbar-collapse",
                        id: "navbarSupportedContent",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                            className: "navbar-nav me-auto mt-0 mb-lg-0",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx(NavItem, {
                                    href: "/about",
                                    text: "من نحن",
                                    classes: liClasses
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx(NavItem, {
                                    href: "/services",
                                    text: "الخدمـات",
                                    classes: liClasses
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx(NavItem, {
                                    href: "/projects",
                                    text: "أعمالنـا",
                                    classes: liClasses
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx(NavItem, {
                                    href: "/contact",
                                    text: "تواصل معنا",
                                    classes: liClasses
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
const NavItem = ({ href, text, classes })=>/*#__PURE__*/ jsx_runtime.jsx("li", {
        className: "nav-item py-3 position-relative",
        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
            legacyBehavior: true,
            href: href,
            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                className: `${classes} link`,
                children: text
            })
        })
    });
/* harmony default export */ const Navbar_Navbar = (Navbar);

// EXTERNAL MODULE: ./Components/Footer/Footer.module.css
var Footer_module = __webpack_require__(9747);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./Components/Footer/Footer.jsx



const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
        className: `${(Footer_module_default()).footer} rounded-1 text-center m-auto mb-4 mt-5`,
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "container text-center",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "col-md-3 col-lg-4 col-xl-3 mx-auto mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("h6", {
                                        className: "fw-bold mb-4 fs-4 text-main",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fas fa-gem me-3 mx-2 text-main"
                                            }),
                                            "النخبه"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("section", {
                                        className: "d-flex justify-content-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "d-flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-facebook-f"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-twitter"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-google"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-instagram"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-linkedin"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "",
                                                    className: "me-4 fs-4 link-secondary",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "fab fa-github"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "col-md-2 col-lg-2 col-xl-2 mx-auto mb-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h6", {
                                        className: "text-uppercase fw-bold mb-4",
                                        children: "Products"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Angular"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "React"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Vue"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Laravel"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "col-md-3 col-lg-2 col-xl-2 mx-auto mb-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h6", {
                                        className: "text-uppercase fw-bold mb-4",
                                        children: "Useful links"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Pricing"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Settings"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Orders"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: "#!",
                                            className: "text-reset",
                                            children: "Help"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h6", {
                                        className: "text-uppercase fw-bold mb-4",
                                        children: "Contact"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fas fa-home me-3 text-secondary"
                                            }),
                                            " New York, NY 10012, US"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fas fa-envelope me-3 text-secondary"
                                            }),
                                            "info@example.com"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fas fa-phone me-3 text-secondary"
                                            }),
                                            " + 01 234 567 88"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fas fa-print me-3 text-secondary"
                                            }),
                                            " + 01 234 567 89"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "text-center p-4",
                children: [
                    "\xa9 2021 Copyright:",
                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                        className: "text-reset fw-bold",
                        href: "https://mdbootstrap.com/",
                        children: "MDBootstrap.com"
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./Layout/Layout.js




function Layout({ children }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(Navbar_Navbar, {}),
            children,
            /*#__PURE__*/ jsx_runtime.jsx(Footer, {})
        ]
    });
}
/* harmony default export */ const Layout_Layout = (Layout);

// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.min.css
var bootstrap_min = __webpack_require__(9090);
// EXTERNAL MODULE: ./node_modules/mdb-ui-kit/css/mdb.min.css
var mdb_min = __webpack_require__(7547);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(1598);
;// CONCATENATED MODULE: ./pages/_app.js











function MyApp({ Component, pageProps }) {
    (0,external_react_.useEffect)(()=>{
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 5075, 23));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com",
                        crossorigin: true
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        href: "https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@100;200;300;400;500;600;700;800;900&display=swap",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "stylesheet",
                        type: "text/css",
                        charSet: "UTF-8",
                        href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "stylesheet",
                        type: "text/css",
                        href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
                        integrity: "sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==",
                        crossorigin: "anonymous",
                        referrerPolicy: "no-referrer"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(Layout_Layout, {
                children: /*#__PURE__*/ jsx_runtime.jsx(Component, {
                    ...pageProps
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx((script_default()) //MDB
            , {
                type: "text/javascript",
                src: "https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.js"
            }),
            /*#__PURE__*/ jsx_runtime.jsx((script_default()), {
                src: "https://unpkg.com/scrollreveal"
            }),
            /*#__PURE__*/ jsx_runtime.jsx((script_default()), {
                src: "https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"
            })
        ]
    });
}


/***/ }),

/***/ 6088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Document)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);


function Document() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {
        lang: "ar",
        dir: "rtl",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5650:
/***/ (() => {



/***/ })

};
;