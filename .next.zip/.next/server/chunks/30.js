"use strict";
exports.id = 30;
exports.ids = [30];
exports.modules = {

/***/ 6030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ outroProjects),
/* harmony export */   y: () => (/* binding */ interiorProjects)
/* harmony export */ });
const interiorProjects = [
    {
        id: 1,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/1.jpg",
            "/2.jpg",
            "/3.jpg",
            "/4.jpg"
        ]
    },
    {
        id: 2,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/5.jpg",
            "/6.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 3,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/2.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 4,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/3.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 5,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/4.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 6,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/5.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 7,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/6.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 8,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/1.jpg",
            "/2.jpg",
            "/3.jpg",
            "/4.jpg"
        ]
    }
];
const outroProjects = [
    {
        id: 1,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/1.jpg",
            "/2.jpg",
            "/3.jpg",
            "/4.jpg"
        ]
    },
    {
        id: 2,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/5.jpg",
            "/6.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 3,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/2.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 4,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/3.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 5,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/4.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 6,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/5.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 7,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/6.jpg",
            "/3.jpg",
            "/7.jpg",
            "/8.jpg"
        ]
    },
    {
        id: 8,
        title: "فيلا",
        description: "وصف لتصميم معماري",
        designer: "أحمد محمد",
        images: [
            "/1.jpg",
            "/2.jpg",
            "/3.jpg",
            "/4.jpg"
        ]
    }
];


/***/ })

};
;